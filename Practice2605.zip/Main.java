//Practice with interfaces
class Main {
  public static void main(String[] args) {
    Triangle abc = new Triangle(5,3,"red");
    Triangle ddf = new Triangle(20, 5,"blue");
    Triangle[] figures = new Triangle[2];
    figures[0] = abc;
    figures[1] = ddf;
    showColor(figures);

  }
  public static void showColor(Triangle[] unknown){
    for ( Triangle index: unknown){
      System.out.println("This is the color " + index.getColor());
    }
  }
}