class Triangle implements Color{
  private int height;
  private int width;
  private String color;

  public Triangle (int height, int width,String color){
    this.height = height;
    this.width = width;
    this.color = color;
  }
  public String getColor(){
    return color;
  }

}