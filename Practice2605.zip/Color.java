public interface Color{
  public String getColor();
}