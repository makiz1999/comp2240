class CruiseShip extends Ship{
  private int numPassenger;

  public CruiseShip(String name, String year, int numPassenger){
    super(name, year);
    this.numPassenger = numPassenger;
  }
  public void setNumPassenger(int numPassenger){
    this.numPassenger = numPassenger;
  }
  public int getNumPassenger(){
    return this.numPassenger;
  }
  @Override
  public String toString(){
    return String.format("Name: %s\nMaximum passengers: %d \n----------------------------", super.getName(), numPassenger);
  }
}