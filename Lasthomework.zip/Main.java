class Main {
  public static void main(String[] args) {
    Ship baloon = new Ship("Baloon", "1885");
    System.out.println(baloon.toString());
    CruiseShip titanic = new CruiseShip("Titanic", "2282", 232);
    System.out.println(titanic.toString());
  }
}