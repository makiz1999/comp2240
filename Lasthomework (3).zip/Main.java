class Main {
  public static void main(String[] args) {
    final int numShips = 6;
    /*Ship baloon = new Ship("Baloon", "1885");
    Ship cube = new Ship("Cube", "1378");
    CruiseShip titanic = new CruiseShip("Titanic", "2282", 232);
    CruiseShip ariel = new CruiseShip("Ariel","2012", 500);
    CargoShip bird = new CargoShip("Bird", "1990", 2000);
    CargoShip levy = new CargoShip("Levy", "1760", 300);*/

    Ship[] ships = new Ship[numShips];
    ships[0] = new Ship("Baloon", "1885");
    ships[1] = new Ship("Cube", "1378");
    ships[2] = new CruiseShip("Titanic", "2282", 232);
    ships[3] = new CruiseShip("Ariel","2012", 500);
    ships[4] = new CargoShip("Bird", "1990", 2000);
    ships[5] = new CargoShip("Levy", "1760", 300);

    for(int i = 0; i < ships.length; i++){
      System.out.println(ships[i]);
      System.out.println("-----------------------");
    }
  }
}